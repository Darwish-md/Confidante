package com.example.confidante;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import okhttp3.MultipartBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class SongsActivity extends AppCompatActivity {

    private Button button;
    private TextView song;
    static String result = null;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_songs);
        button = findViewById(R.id.detect_songs_btn);
        song = findViewById(R.id.song_detected);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                detect();
                //song.setText(result);
            }
        });

    }

    public static void detect() {
        try {
            OkHttpClient client = new OkHttpClient();
            RequestBody data = new MultipartBody.Builder().setType(MultipartBody.FORM)
                    .addFormDataPart("api_token", "ac61b9d8de140bd9f3e29702f9ed92e3").build();
            Request request = new Request.Builder().url("https://api.audd.io/getCallbackUrl/")
                    .post(data).build();
            Response response = null;
            response = client.newCall(request).execute();
            result = response.body().string();
            System.out.println(result);
        } catch (Exception e) {
            e.printStackTrace();
        }
}}